import UIKit

import SwiftUI

let x = 3
let y = 4


print("Simple Calc Answers")

print("x+y:")

print(x + y)

print("x-y:")

print ( x - y)

print("y-x:")

print(y - x)

print("x/y:")

print( x / y)

print("y/x:")

print(y / x)

print("x*y:")

print(x * y)
